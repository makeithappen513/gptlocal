import os
import streamlit as st
from streamlit_chat import message
from langchain.chat_models import AzureChatOpenAI
from langchain.schema import HumanMessage
from langchain.llms import AzureOpenAI
#Vector database
from langchain.vectorstores import Chroma
from langchain.chains import RetrievalQA
# Convert raw text to vector embedding engine
from langchain.embeddings.azure_openai import AzureOpenAIEmbeddings
# Streaming callbacks
from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler


def generate_response(llm,retriever,question):
    qa = RetrievalQA.from_chain_type(llm=chat_model, chain_type="stuff", retriever=retriever)
    answer = qa.run(question)
    return answer

openai_api_key = "5d4d1d30e5704cc3b2812f8304e432fe" 

chat_model = AzureChatOpenAI(
    openai_api_key=openai_api_key, #you apikey,
    azure_endpoint="https://pubwebpoc.openai.azure.com/",
    openai_api_version="2023-05-15",
    azure_deployment="testchat",
    model_name="gpt-35-turbo",
    streaming=True,
    callbacks=[StreamingStdOutCallbackHandler()]
)

#Embedding Engine
embeddings = AzureOpenAIEmbeddings(
    openai_api_key=openai_api_key,
    azure_endpoint="https://pubwebpoc.openai.azure.com/",
    azure_deployment="text-embedding-ada-002",
    openai_api_version="2023-07-01-preview",
    model = "text-embedding-ada-002"
    )

vectordb = Chroma(embedding_function=embeddings, persist_directory="./cut")

st.set_page_config(
    page_title="VLK ClientCenter ChatBot",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="expanded"
)
st.title("VLK ClientCenter ChatBot🤖")

if 'generated' not in st.session_state:
    st.session_state['generated'] = []
if 'past' not in st.session_state:
    st.session_state['past'] = []
user_input = st.text_input("VLK ClientCenter ChatBot",key='input')
if user_input:
    #create search engine
    retriever=vectordb.as_retriever()
    output=generate_response(chat_model,retriever,user_input)
    #store the output
    st.session_state['past'].append(user_input)
    st.session_state['generated'].append(output)

if st.session_state['generated']:
    for i in range(len(st.session_state['generated'])-1, -1, -1):
        message(st.session_state["generated"][i], key=str(i))
        message(st.session_state['past'][i], is_user=True, key=str(i) + '_user')



